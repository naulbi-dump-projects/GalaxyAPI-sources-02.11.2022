package ru.galaxy773.multiplatform.api.gamer.customization.tituls;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum TitulsCategory {

    BASE,
    SPECIAL,
    NEW_YEAR,
    ANIME,
    MARVEL,
    GAMING
}
