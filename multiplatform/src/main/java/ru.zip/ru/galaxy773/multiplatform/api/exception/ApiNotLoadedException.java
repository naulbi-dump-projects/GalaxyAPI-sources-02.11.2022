package ru.galaxy773.multiplatform.api.exception;

public class ApiNotLoadedException extends IllegalArgumentException {
}
