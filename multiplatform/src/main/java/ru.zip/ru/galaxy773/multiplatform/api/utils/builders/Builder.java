package ru.galaxy773.multiplatform.api.utils.builders;

public interface Builder<T> {

    T build();
}
