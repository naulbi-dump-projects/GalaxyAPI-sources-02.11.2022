package ru.galaxy773.multiplatform.api.sql.query;

public interface Query {

    String toString();
}
