package ru.galaxy773.multiplatform.api.placeholder;

public enum PlaceholderType {

    SUPPLIER,
    GAMER,
    ARGUMENTED;
}
