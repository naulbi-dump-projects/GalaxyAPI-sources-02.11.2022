package ru.galaxy773.multiplatform.api.boxes;

public enum AnimationType {

    CIRCLE,
    CONUS;
}
