package ru.galaxy773.multiplatform.impl.skin.response;

public final class UUIDResponse extends SkinsResponse {

    public UUIDResponse(String id, String name, String message, String type, String error, int status) {
        super(id, name, message, type, error, status);
    }
}
